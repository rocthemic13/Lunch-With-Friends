# Lunch-With-Friends
Lunch application/website to coordinate meal sharing among friends and co-workers

Two or more pages
  - One for the "chef" to add meals, dictate prices, dates and times
  - One for the patrons to "buy-in" or reserve their portion of made lunch
  
Will be utilizing HTML and JavaScript to create application/webpage

Collaborative project between Data Science ERG Group
